Database of covid diagnosed people and controls
